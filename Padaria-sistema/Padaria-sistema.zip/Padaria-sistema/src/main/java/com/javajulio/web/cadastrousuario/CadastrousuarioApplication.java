package com.javajulio.web.cadastrousuario;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = "com.javajulio.web.cadastrousuario")

public class CadastrousuarioApplication {

    public static void main(String[] args) {
        SpringApplication.run(CadastrousuarioApplication.class, args);
    }

}
