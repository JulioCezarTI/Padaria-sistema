package com.javajulio.web.cadastrousuario.infrastructure.entitys;

public @interface JsonFormat {
    String pattern();
}
