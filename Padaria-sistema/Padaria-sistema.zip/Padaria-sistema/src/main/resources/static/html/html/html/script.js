const clientes = [];
let clienteAtualIndex = null;

const nomeInput = document.getElementById("nomeUsuario");
const telefoneInput = document.getElementById("telefoneUsuario");
const nomeProdutoInput = document.getElementById("nomeProduto");
const quantidadeProdutoInput = document.getElementById("quantidadeProduto");
const precoProdutoInput = document.getElementById("precoProduto");
const mensagemSucesso = document.getElementById("mensagemSucesso");
const notaFiscalDiv = document.getElementById("notaFiscal");
const clientesListDiv = document.getElementById("clientesList");

const btnRegistrarUsuario = document.getElementById("btnRegistrarUsuario");
const btnAdicionarProduto = document.getElementById("btnAdicionar");
const btnFinalizar = document.getElementById("btnFinalizar");

const botaoMusica = document.getElementById("botaoMusica");
const musicaFundo = document.getElementById("musicaFundo");

// Registrar Usuário
btnRegistrarUsuario.addEventListener("click", () => {
    const nome = nomeInput.value.trim();
    const telefone = telefoneInput.value.trim();

    if (!nome || !telefone) {
        mensagemSucesso.textContent = "Preencha o nome e telefone do cliente!";
        mensagemSucesso.style.color = "red";
        return;
    }

    // Verifica se já existe o cliente
    const existe = clientes.findIndex(c => c.nome === nome && c.telefone === telefone);
    if (existe !== -1) {
        mensagemSucesso.textContent = "Cliente já registrado. Você pode adicionar produtos agora.";
        mensagemSucesso.style.color = "orange";
        clienteAtualIndex = existe;
    } else {
        clientes.push({ nome, telefone, produtos: [] });
        clienteAtualIndex = clientes.length - 1;
        mensagemSucesso.textContent = "✅ Cliente registrado com sucesso! Agora adicione produtos.";
        mensagemSucesso.style.color = "green";
    }

    atualizarListaClientes();
    atualizarNotaFiscal(clienteAtualIndex);

    // Habilita inputs e botões de produtos
    nomeProdutoInput.disabled = false;
    quantidadeProdutoInput.disabled = false;
    precoProdutoInput.disabled = false;
    btnAdicionarProduto.disabled = false;
    btnFinalizar.disabled = false;

    // Desabilita inputs cliente para evitar mudanças erradas
    nomeInput.disabled = true;
    telefoneInput.disabled = true;
});

// Adicionar Produto
btnAdicionarProduto.addEventListener("click", () => {
    if (clienteAtualIndex === null) {
        mensagemSucesso.textContent = "Registre um usuário antes de adicionar produtos.";
        mensagemSucesso.style.color = "red";
        return;
    }

    const nomeProduto = nomeProdutoInput.value.trim();
    const quantidade = parseInt(quantidadeProdutoInput.value);
    const precoInput = precoProdutoInput.value.trim().replace(",", ".");
    const preco = Number(precoInput);

    if (!nomeProduto || isNaN(quantidade) || isNaN(preco) || quantidade <= 0 || preco <= 0) {
        mensagemSucesso.textContent = "Preencha todos os campos do produto corretamente!";
        mensagemSucesso.style.color = "red";
        return;
    }

    clientes[clienteAtualIndex].produtos.push({ nome: nomeProduto, quantidade, preco });

    mensagemSucesso.textContent = `✅ Produto "${nomeProduto}" adicionado para ${clientes[clienteAtualIndex].nome}!`;
    mensagemSucesso.style.color = "green";

    atualizarListaClientes();
    atualizarNotaFiscal(clienteAtualIndex);

    // Limpa os campos do produto
    nomeProdutoInput.value = "";
    quantidadeProdutoInput.value = "";
    precoProdutoInput.value = "";
});

// Função para remover produto da lista do cliente pelo índice do produto
function removerProduto(idxProduto) {
    if (clienteAtualIndex === null) return;

    const cliente = clientes[clienteAtualIndex];
    cliente.produtos.splice(idxProduto, 1); // Remove o produto da lista

    mensagemSucesso.textContent = `❌ Produto removido!`;
    mensagemSucesso.style.color = "orange";

    atualizarListaClientes();
    atualizarNotaFiscal(clienteAtualIndex);
}

// Atualiza lista de clientes na lateral
function atualizarListaClientes() {
    clientesListDiv.innerHTML = "";

    clientes.forEach((cliente, idx) => {
        const divCliente = document.createElement("div");
        divCliente.className = "clienteItem";

        divCliente.textContent = `${cliente.nome} (${cliente.telefone}) - ${cliente.produtos.length} produto(s)`;

        divCliente.onclick = () => {
            clienteAtualIndex = idx;
            atualizarNotaFiscal(idx);
            mensagemSucesso.textContent = `Mostrando compras de ${cliente.nome}`;
            mensagemSucesso.style.color = "black";

            // Habilita inputs para esse cliente
            nomeInput.disabled = true;
            telefoneInput.disabled = true;
            nomeProdutoInput.disabled = false;
            quantidadeProdutoInput.disabled = false;
            precoProdutoInput.disabled = false;
            btnAdicionarProduto.disabled = false;
            btnFinalizar.disabled = false;
        };

        clientesListDiv.appendChild(divCliente);
    });
}

// Atualiza a nota fiscal na tela para o cliente selecionado
function atualizarNotaFiscal(idx) {
    if (idx === null || idx === undefined) {
        notaFiscalDiv.innerHTML = "Nenhum cliente selecionado.";
        return;
    }
    const cliente = clientes[idx];

    if(cliente.produtos.length === 0) {
        notaFiscalDiv.innerHTML = `<strong>${cliente.nome}</strong><br>Nenhum produto adicionado.`;
        return;
    }

    let notaHTML = `<strong>Nota Fiscal - ${cliente.nome}</strong><br>`;
    notaHTML += `Telefone: ${cliente.telefone}<br>`;
    const dataHora = new Date().toLocaleString("pt-BR");
    notaHTML += `<strong>Data/Hora do Pedido:</strong> ${dataHora}<br><ul>`;

    let total = 0;
    cliente.produtos.forEach((prod, idxProd) => {
        const subtotal = prod.quantidade * prod.preco;
        total += subtotal;
        notaHTML += `<li>${prod.quantidade}x ${prod.nome} - R$ ${subtotal.toFixed(2)} 
        <button onclick="removerProduto(${idxProd})">❌ Remover</button>
        </li>`;
    });

    notaHTML += `</ul><strong>Total: R$ ${total.toFixed(2)}</strong>`;
    notaFiscalDiv.innerHTML = notaHTML;
}

// Finalizar Compra
btnFinalizar.addEventListener("click", () => {
    if (clienteAtualIndex === null) {
        mensagemSucesso.textContent = "Nenhum cliente selecionado.";
        mensagemSucesso.style.color = "red";
        return;
    }
    if (clientes[clienteAtualIndex].produtos.length === 0) {
        mensagemSucesso.textContent = "Nenhum produto adicionado para finalizar.";
        mensagemSucesso.style.color = "red";
        return;
    }

    mensagemSucesso.textContent = `🧁 Compra finalizada para ${clientes[clienteAtualIndex].nome}!`;
    mensagemSucesso.style.color = "green";

    // Reseta para novo cliente (opcional)
    clienteAtualIndex = null;
    nomeInput.disabled = false;
    telefoneInput.disabled = false;

    nomeProdutoInput.disabled = true;
    quantidadeProdutoInput.disabled = true;
    precoProdutoInput.disabled = true;
    btnAdicionarProduto.disabled = true;
    btnFinalizar.disabled = true;

    notaFiscalDiv.innerHTML = "Nenhum cliente selecionado.";

    // Limpa campos cliente para novo cadastro
    nomeInput.value = "";
    telefoneInput.value = "";
    nomeProdutoInput.value = "";
    quantidadeProdutoInput.value = "";
    precoProdutoInput.value = "";

    atualizarListaClientes();
});

// Controle do botão da música
botaoMusica.addEventListener("click", () => {
    if (musicaFundo.paused) {
        musicaFundo.play();
        botaoMusica.textContent = "⏸️ Pausar Música";
    } else {
        musicaFundo.pause();
        botaoMusica.textContent = "▶️ Tocar Música";
    }
});

// Para a função removerProduto funcionar no onclick inline, deixa ela global
window.removerProduto = removerProduto;
